# Clean Strike
	
	It is a carrom board game for 2 players. Based on different types of strike inputs
	in each turn, the players result is decided.

# How to Test ?
	Run "CarromTest.java" junit file under "src/test/java/playcarrom/" to verify all the test cases..